/* Grupo: Clara Franca Passamani, Isadora Gomes Melo Cunha e Lívia Della Garza Silva
 * Turma 10A
 * Tema: Músicos
*/

#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

struct musicos{
	string nome;
	int idade;
	string pais;
	string genero;
	string funcao;
	char carreira;
};

musicos leitura (ifstream& arq){
	musicos musico;
	char lixo; //Armazenar a vírgula.
	
	getline (arq, musico.nome,',');
	arq >> musico.idade;
	arq >> lixo;
	getline (arq, musico.pais,',');
	getline (arq, musico.genero,',');
	getline (arq, musico.funcao,',');
	arq >> musico.carreira;
	arq.ignore();
	
	return musico;
}

void inserir(musicos musico[], int posicao){
	do{
		cout << "Insira a idade: ";
		cin >> musico[posicao].idade;
		if (cin.fail()){ 
			cin.clear();
			cin.ignore(); 
			cout << "A idade deve ser um número inteiro maior que 0." << endl;
		}
	}while (musico[posicao].idade==0); //Verifica se o usuário digitou um número inteiro. Se não, será atribuído o valor 0 ao campo idade.
	cout << "Insira o país de nascimento: ";
	cin.ignore();
	getline(cin, musico[posicao].pais);
	cout << "Insira o gênero musical principal: ";
	cin >> musico[posicao].genero;
	cout << "Insira a função (instrumento) principal: ";
	cin >> musico[posicao].funcao;
	cout << "Insira a carreira principal (solo ou banda): ";
	cin >> musico[posicao].carreira;
} 	

 void imprime (musicos musico[], int posicao){ 
	cout << endl << "Nome: " << musico[posicao].nome << endl << "Idade: " << musico[posicao].idade << endl << "País de nascimento: " << musico[posicao].pais << endl
	<< "Gênero musical principal: " << musico[posicao].genero << endl << "Função principal: " << musico[posicao].funcao << endl << "Carreira principal (solo ou banda): " << 
	musico[posicao].carreira << endl << endl;
}

int main(){
	int tamanho = 0;
	string medidor; 
	ifstream arquivo ("entrada.csv");
	while (getline (arquivo, medidor)){ 
		tamanho++; //Contabiliza a quantidade de linhas do arquivo.
	}
	arquivo.close();
	
	musicos* musico = new musicos[tamanho]; //Alocação dinâmica com uso de ponteiros.
	string nomE, funcaO;
	ifstream arq ("entrada.csv");
	if (arq){
		for (int i=0; i<tamanho; i++){
			musico[i] = leitura(arq);
		}
	
		int n; //Variável usada como condição nos blocos condicionais principais.
		
		bool existe; //Usada para verificar se o nome ou a função digitada pelo usuário existe no banco de dados. Atribuída como "false" ao início de cada um dos quatro blocos condicionais principais.
		
		cout << "Seja bem-vindo ao sistema de cadastro de músicos!" << endl << endl;
	
		do{
			cout << "O que você está buscando?" << endl << "Para buscar, digite 1." << endl << "Para editar, digite 2." <<
			endl << "Para realizar uma remoção, digite 3." << endl << "Para realizar uma inserção, digite 4." << endl;
			cin >> n;
			if (cin.fail()){  
				cin.clear();
				cin.ignore();
			}
		
			if (n==1){
				int n2; //Variável usada como condição no escopo deste bloco.
				existe = false;
				cout << "Se você deseja buscar pelo nome do músico, digite 1." << endl << "Se você deseja buscar pela sua função, digite 2." << endl;
				cin >> n2;
				if (cin.fail()){
					cin.clear();
					cin.ignore();
				}
			
				if (n2==1){
					cin.ignore();
					cout << "Insira o nome do músico que você deseja pesquisar: ";
					getline(cin, nomE);
					for (int i=0; i<tamanho; i++){
						if (nomE==musico[i].nome and musico[i].idade!=-1){
							imprime (musico, i);
							existe=true;
						}
					}
					if(not existe){
						cout << "Não há nenhum músico cadastrado com esse nome." << endl << 
						"Se você deseja cadastrar um músico com esse nome, digite 4. Se não, digite 1." << endl;
						cin >> n;
						if (cin.fail()){
							cin.clear();
							cin.ignore();
						}
					}
					
				}else if (n2==2){
					cout << "Insira a função do músico que você deseja pesquisar: ";
					cin >> funcaO;
					for (int i=0; i<tamanho; i++){
						if (funcaO==musico[i].funcao and musico[i].idade!=-1){
							imprime (musico, i);
							existe = true;
						}
					}
					if(not existe){
						cout << "Não há nenhum músico cadastrado que possui a função inserida." << endl <<
						"Se você deseja cadastrar um músico com essa função, digite 4. Se não, digite 1." << endl;
						cin >> n;
						if (cin.fail()){
							cin.clear();
							cin.ignore();
						}
					}
					
				}else{
					cout << "Número inválido." << endl;
				}
				
			}if (n==3){
				existe = false;
				cout << "Você deseja remover os dados de qual músico?" << endl;
				cin.ignore();
				getline(cin,nomE);
				for(int i=0;i<tamanho;i++){
					if (nomE==musico[i].nome){
						musico[i].nome=" ";
						musico[i].idade=-1;
						musico[i].pais=" ";
						musico[i].genero=" ";
						musico[i].funcao=" ";
						musico[i].carreira=' '; //Remoção a partir da substituição por espaços ou número negativo.
						existe = true;
						cout << "Remoção realizada com sucesso." << endl;
					}
				}
		
				if (not existe){
					cout << "Não há nenhum músico cadastrado com esse nome." << endl;
				}
				
		
			}if (n==4){
				existe = false;
				bool removido = false;
				cout << endl << "Insira o novo nome: ";
				cin.ignore();
				getline(cin, nomE);
				for (int j=0; j<tamanho; j++){
					if (nomE==musico[j].nome){
						existe = true;
					}
				}
				if (existe){
					cout << endl << "Esse músico já se encontra cadastrado." << endl <<
					"Se você quiser editar os dados desse ou de outro músico, digite 2." << endl <<
					"Se não, digite 1." << endl;
					cin >> n;
					if (cin.fail()){
						cin.clear();
						cin.ignore();
					}
					cout << endl;
				
				}else{
					int i=0;
					while(i<tamanho and removido==false){
						if (musico[i].idade==-1){
							musico[i].nome=nomE;
							inserir (musico, i);
							removido = true;
							cout << endl << "Novo músico cadastrado:" << endl;
							imprime(musico,i);
						}
						i++;
					}
					if (not removido){
						musicos* musicoNovo = new musicos[tamanho+1];
						copy (musico, musico+tamanho, musicoNovo);
						delete[] musico;
						musico = musicoNovo;
						musico[tamanho].nome=nomE;
						inserir (musicoNovo, tamanho);
						tamanho++;
						cout << endl << "Novo músico cadastrado:" << endl;
						imprime(musico,tamanho-1);
					} 
				}
				
			}if (n==2){
				existe = false;
				cout << "Você deseja editar os dados de qual músico?" << endl;
				cin.ignore();
				getline(cin, nomE);
				for (int i=0; i<tamanho; i++){
					if (nomE==musico[i].nome){
						imprime (musico, i);
						existe = true;
					}
				}
	
				if (existe){
					int n2; //Variável usada como condição no escopo deste bloco.
					cout << "Qual dado você deseja editar?" << endl << "Nome: digite 1." << endl << "Idade: digite 2." << endl << "País de nascimento: digite 3." << endl <<
					"Gênero musical principal: digite 4." << endl << "Função principal: digite 5." << endl << "Carreira principal: digite 6" << endl;
					cin >> n2;
					if (cin.fail()){
						cin.clear();
						cin.ignore();
					}
			
					if (n2==1){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
								cout << "Insira o novo nome: ";
								cin.ignore();
								getline(cin, musico[i].nome);
								cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
								imprime(musico,i);
							}		
						}
							
					}else if (n2==2){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
								cout << "Insira a nova idade: ";
								cin >> musico[i].idade;
								cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
								imprime(musico,i);
							}		
						}
					}else if (n2==3){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
								cout << "Insira o novo país: ";
								cin.ignore();
								getline(cin, musico[i].pais);
								cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
								imprime(musico,i);
							}		
						}
							
					}else if (n2==4){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
							cout << "Insira o novo gênero musical: ";
							cin >> musico[i].genero;
							cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
							imprime(musico,i);
							}
						}
						
					}else if (n2==5){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
							cout << "Insira a nova função: ";
							cin >> musico[i].funcao;
							cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
							imprime(musico,i);
							}
						}	
						
					}else if (n2==6){
						for (int i=0; i<tamanho; i++){
							if (nomE==musico[i].nome){
							cout << "Insira o novo tipo de carreira: ";
							cin >> musico[i].carreira;
							cout << endl << "Aqui estão os dados com a alteração solicitada:" << endl;
							imprime(musico,i);
							}
						}
						
					}else{
						cout << "Número inválido." << endl;
					}
					
				}else{
					cout << "Não há nenhum músico cadastrado com esse nome." << endl;
				}
		
			}if (n!=1 and n!=2 and n!=3 and n!=4){
			cout << "Número inválido." << endl;
		}
		cout << "Se você deseja voltar para o menu inicial, digite 1." << endl <<
		"Se desejar fechar o programa, digite qualquer outro número ou letra." << endl;
		cin >> n;
		cout << endl;
		
		}while(n==1); //Irá voltar para o menu, se o usuário digitar 1.
		
		
	}else{
		cout << "Não foi possível abrir o arquivo corretamente." << endl;
	}
		
	return 0;
}
